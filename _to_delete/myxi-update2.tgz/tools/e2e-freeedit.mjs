/**
 * ブラウザ E2E: フリーエディットのドラッグ / 自動是正 / トグル
 *   node tools/e2e-freeedit.mjs
 * 事前に `node tools/mock-supabase.mjs` と `npx vite preview --port 4173` を起動しておくこと。
 */
import { chromium } from 'playwright';

const BASE = 'http://127.0.0.1:4173/';
const ok = (label, cond, extra = '') =>
  console.log(`${cond ? '✅' : '❌'} ${label}${extra ? `  ${extra}` : ''}`);
let failures = 0;
const check = (label, cond, extra) => {
  if (!cond) failures++;
  ok(label, cond, extra);
};

const browser = await chromium.launch(
  process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {},
);
const page = await browser.newPage({ viewport: { width: 1400, height: 1100 } });
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));
// favicon 等の 404 は本体と無関係なので除く
page.on('console', (m) => {
  if (m.type() !== 'error') return;
  const t = m.text();
  if (t.includes('Failed to load resource') && t.includes('404')) return;
  // テスト環境は外部（Google Fonts）に出られない
  if (t.includes('ERR_TUNNEL_CONNECTION_FAILED') || t.includes('ERR_NAME_NOT_RESOLVED')) return;
  errors.push(t);
});

const API = 'http://localhost:54321/rest/v1';

/* ── 未ログイン：入口だけが見え、他人のデータは取れない ───────── */
await page.goto(BASE, { waitUntil: 'networkidle' });
check('最初はホーム（趣旨説明）が開く', (await page.getByTestId('home').count()) === 1);
check('未ログインでは Google ログインの入口が出る', (await page.getByRole('button', { name: /Google でログイン/ }).count()) >= 1);
check('未ログインでも戦術ボードへの入口がある', (await page.getByRole('button', { name: 'ログインせずにボードを触る' }).count()) === 1);
await page.screenshot({ path: '/tmp/home-guest.png', fullPage: true });
check('未ログインでは他人のプロフィール一覧が出ない', (await page.getByText('登録済みのユーザー').count()) === 0);
const anonProfiles = await (await fetch(`${API}/profiles?select=*`, { headers: { apikey: 'mock' } })).json();
check('未ログインの API からはプロフィールが読めない', Array.isArray(anonProfiles) && anonProfiles.length === 0, `${anonProfiles.length}件`);

/* ── ログイン済みセッションを入れて開く ───────────────────── */
const session = JSON.parse(process.env.E2E_SESSION);
await page.evaluate((s) => localStorage.setItem('buildup-board:session', JSON.stringify(s)), session);
await page.reload({ waitUntil: 'networkidle' });
await page.waitForTimeout(1500);
check('ログイン後もホームから始まる', (await page.getByTestId('home').count()) === 1);
await page.getByRole('button', { name: '戦術提案をはじめる' }).click();
await page.waitForTimeout(300);
check('選手がそろっていればホームから戦術提案へ進める', (await page.getByRole('button', { name: 'この相手に効く形を探す' }).count()) === 1);

/* ── チームカラー ─────────────────────────────────────── */
await page.getByTitle('クラブの設定').click();
await page.waitForTimeout(300);
await page.getByRole('radio', { name: 'アズール' }).click();
await page.waitForTimeout(400);
const teamHex = await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--team-hex').trim());
check('チームカラーを選ぶと画面の色が変わる', teamHex === '#4d8dff', teamHex);
await page.reload({ waitUntil: 'networkidle' });
await page.waitForTimeout(1500);
const teamHex2 = await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--team-hex').trim());
check('チームカラーが保存され、開き直しても残る', teamHex2 === '#4d8dff', teamHex2);

// 選手タブ
await page.getByRole('button', { name: '選手', exact: true }).click();
await page.waitForTimeout(500);

/* ── 適性ポジションの登録 ─────────────────────────────── */
const subHeader = await page.getByText(/適性ポジション/).count();
check('適性ポジションの列が出る', subHeader > 0);

// 先頭のフィールドプレーヤー（GK 以外）の行で2つ選ぶ
const chips = page.locator('tbody tr').nth(3).locator('button');
const chipCount = await chips.count();
check('適性ポジションの選択肢が出る', chipCount > 0, `${chipCount}個`);
await chips.nth(0).click();
await chips.nth(1).click();
await page.waitForTimeout(200);
const selected = await page
  .locator('tbody tr')
  .nth(3)
  .locator('button.border-team\\/70')
  .count();
check('適性ポジションが2つ選択される', selected === 2, `${selected}個`);

// 上限4つまで選び、5つ目は押せなくなること
await chips.nth(2).click();
await chips.nth(3).click();
await page.waitForTimeout(200);
const capped = await page
  .locator('tbody tr')
  .nth(3)
  .locator('button.border-team\\/70')
  .count();
check('適性ポジションを4つ選べる', capped === 4, `${capped}個`);
check('5つ目は押せない（上限4）', await chips.nth(4).isDisabled());

// 1つ外せばまた選べる
await chips.nth(0).click();
await page.waitForTimeout(200);
check('外すと上限が空く', !(await chips.nth(4).isDisabled()));

/* ── 戦術提案タブ → フリーエディット ─────────────────── */
await page.getByRole('button', { name: '戦術提案' }).click();
await page.waitForTimeout(600);

const warn = await page.getByText(/起用できる選手がまだ足りません/).count();
check('23名が登録され、提案タブが使える', warn === 0);

/* ── 相手の形の入力（プリセット＋人数） ───────────────────── */
const picker = page.getByTestId('opponent-picker');
const oppName = () => page.getByTestId('opponent-picker-name').innerText();
check('既定の相手は 4-2-3-1', (await oppName()) === '4-2-3-1');
await picker.getByRole('button', { name: '4-3-3', exact: true }).click();
await page.waitForTimeout(150);
check('プリセット1タップで 4-3-3 になる', (await oppName()) === '4-3-3');

await picker.getByRole('button', { name: 'クリア' }).click();
await page.waitForTimeout(100);
check('クリアで「あと10人」になる', (await picker.locator('span[role=status]').innerText()) === 'あと10人');

// 4-1-2-3 を人数で組む: LSB/RSB, CB×2, DMF×1, OMF×2, LWG/RWG, CF×1
const tap = (name, n = 1) => Array.from({ length: n }).reduce((p) => p.then(() => picker.getByRole('button', { name, exact: true }).click()), Promise.resolve());
await tap('LSB'); await tap('RSB');
await tap('CBを増やす', 2); await tap('DMFを増やす'); await tap('OMFを増やす', 2);
await tap('LWG'); await tap('RWG'); await tap('CFを増やす');
await page.waitForTimeout(150);
check('人数入力で 4-1-2-3 が組める', (await oppName()) === '4-1-2-3', await oppName());
check('10人そろうと OK になる', (await picker.locator('span[role=status]').innerText()) === '10人 OK');
check('10人そろうと増やすボタンが止まる', await picker.getByRole('button', { name: 'STを増やす' }).isDisabled());
await tap('CBを減らす');
await page.waitForTimeout(100);
check('CB の上限は3（2→1→+で戻せる）', !(await picker.getByRole('button', { name: 'CBを増やす' }).isDisabled()));
await tap('CBを増やす', 1);
await page.waitForTimeout(100);

// 以降は 4-2-3-1 で盤面操作を試す
await picker.getByRole('button', { name: '4-2-3-1', exact: true }).click();
await page.waitForTimeout(300);

const svg = page.locator('svg').filter({ has: page.locator('circle') }).last();
const box = await svg.boundingBox();
check('編集できるピッチが出る', !!box);

/** ピッチ座標 → 画面座標 */
const toScreen = (x, y) => ({
  x: box.x + (x / 105) * box.width,
  y: box.y + ((68 - y) / 68) * box.height,
});

/** 現在のトークン一覧（ピッチ座標とポジション）を DOM から読む */
const readTokens = () =>
  page.evaluate(() => {
    const svgs = [...document.querySelectorAll('svg')];
    const target = svgs[svgs.length - 1];
    return [...target.querySelectorAll('g')]
      .map((g) => {
        const c = g.querySelector('circle[r="2.2"]');
        const texts = [...g.querySelectorAll('text')];
        if (!c || texts.length < 2) return null;
        return {
          number: texts[0].textContent.trim(),
          position: texts[1].textContent.trim(),
          x: +c.getAttribute('cx'),
          y: 68 - +c.getAttribute('cy'),
        };
      })
      .filter(Boolean);
  });

const before = await readTokens();
check('11人のトークンが描かれている', before.length === 11, `${before.length}人`);

/* 相手は away なので、実座標は鏡映。自チーム基準では (105-x, 68-y) */
const own = (t) => ({ x: 105 - t.x, y: 68 - t.y });

/* ── 1. ドラッグ＋自動是正: CB を自チーム基準の右サイド守備へ運ぶ ── */
const cb = before.find((t) => t.position === 'CB');
check('CB がいる', !!cb);
// 自チーム基準 (20, 8) = 右サイド守備 → 相手の実座標は (85, 60)
const from = toScreen(cb.x, cb.y);
const to = toScreen(85, 60);
await page.mouse.move(from.x, from.y);
await page.mouse.down();
await page.mouse.move(to.x, to.y, { steps: 12 });
await page.mouse.up();
await page.waitForTimeout(250);

const afterDrag = await readTokens();
const moved = afterDrag.find((t) => t.number === cb.number);
const movedOwn = own(moved);
check(
  'ドラッグで任意座標へ動く',
  Math.abs(moved.x - 85) < 3 && Math.abs(moved.y - 60) < 3,
  `→ (${moved.x.toFixed(1)}, ${moved.y.toFixed(1)})`,
);
check(
  '自動是正: 右サイド守備に落とした CB が RSB になる',
  moved.position === 'RSB',
  `${cb.position} → ${moved.position}  自チーム基準(${movedOwn.x.toFixed(0)}, ${movedOwn.y.toFixed(0)})`,
);

/* ── 2. トグル: 中央アンカー帯に置いてクリックすると DMF ⇄ CMF ── */
// 自チーム基準 (42, 34) → 相手実座標 (63, 34)
const anchorTo = toScreen(63, 34);
const cur = toScreen(moved.x, moved.y);
await page.mouse.move(cur.x, cur.y);
await page.mouse.down();
await page.mouse.move(anchorTo.x, anchorTo.y, { steps: 12 });
await page.mouse.up();
await page.waitForTimeout(250);

let t = (await readTokens()).find((x) => x.number === cb.number);
check('中央アンカー帯へ動かすと DMF になる', t.position === 'DMF', `→ ${t.position}`);

const clickAt = toScreen(t.x, t.y);
await page.mouse.click(clickAt.x, clickAt.y);
await page.waitForTimeout(200);
t = (await readTokens()).find((x) => x.number === cb.number);
check('クリックでトグル DMF → CMF', t.position === 'CMF', `→ ${t.position}`);

await page.mouse.click(clickAt.x, clickAt.y);
await page.waitForTimeout(200);
t = (await readTokens()).find((x) => x.number === cb.number);
check('もう一度クリックで CMF → DMF', t.position === 'DMF', `→ ${t.position}`);

/* ── 3. 編集済みの配置で提案が走る ────────────────────── */
await page.getByRole('button', { name: 'この相手に効く形を探す' }).click();
await page.waitForTimeout(5000);

const hasDensity = await page.getByText('相手配置の密度解析').count();
check('密度解析カードが出る', hasDensity > 0);
const hasBest = await page.getByText(/攻撃時の詳細/).count();
check('推奨フォーメーションの詳細が出る', hasBest > 0);
const hasSpace = await page.getByText('空きの活用').count();
check('「空きの活用」列がある', hasSpace > 0);

await page.screenshot({ path: '/tmp/freeedit.png', fullPage: true });

/* ── 4. 評価モデルを切り替えると結果が変わる ──────────────── */
/** 推奨フォーメーション名 + ランキング表の並び */
const bestOf = () =>
  page.evaluate(() => {
    const title = [...document.querySelectorAll('*')]
      .map((el) => el.textContent ?? '')
      .find((t) => t.startsWith('推奨フォーメーション')) ?? '';
    // ランキング表は最後の table
    const tables = [...document.querySelectorAll('table')];
    const order = tables.length
      ? [...tables[tables.length - 1].querySelectorAll('tbody tr td:first-child')]
          .map((td) => td.textContent.trim().replace('推奨', ''))
          .join(',')
      : '';
    return `${title.slice(0, 40)}|${order}`;
  });
const beforeSwitch = await bestOf();

// 「評価モデル（試験）」の select を パスコース重視 に変える（詳しい条件の中）
await page.getByText('詳しい条件（局面・評価モデル）').click();
const selects = page.locator('select');
const modelSelect = selects.nth((await selects.count()) - 1);
await modelSelect.selectOption({ label: 'パスコース重視' });
await page.waitForTimeout(200);
await page.getByRole('button', { name: 'この相手に効く形を探す' }).click();
await page.waitForTimeout(6000);

const afterSwitch = await bestOf();
check('評価モデルを切り替えると提案が変わる', beforeSwitch !== afterSwitch);
const passHeader = await page.getByText('自チームのパスコース').count();
check('見出しが「パスコース」表記に変わる', passHeader > 0);

await page.screenshot({ path: '/tmp/passoptions.png', fullPage: true });

/* ── 5. 一覧の表示件数の切り替え ───────────────────────── */
const rowCount = () =>
  page.evaluate(() => {
    const tables = [...document.querySelectorAll('table')];
    return tables.length ? tables[tables.length - 1].querySelectorAll('tbody tr').length : 0;
  });

const topN = await rowCount();
check('既定では一覧が上位だけに絞られている', topN > 0 && topN <= 10, `${topN}行`);

await page.getByRole('button', { name: '基本形ごと' }).click();
await page.waitForTimeout(300);
const famN = await rowCount();
check('「名前ごと」で1行ずつになる', famN >= 30 && famN <= 70, `${famN}行`);

await page.getByRole('button', { name: 'すべて' }).click();
await page.waitForTimeout(500);
const allN = await rowCount();
check('「すべて」で全行が出る', allN > 50, `${allN}行`);

await page.getByRole('button', { name: /^上位/ }).click();
await page.waitForTimeout(300);
check('「上位」に戻せる', (await rowCount()) === topN);

// タイプのバッジが出ているか（「4CB／…」のような構成名）
const badge = await page.getByText(/／/).count();
check('タイプ名が一覧に出ている', badge > 0);

// 攻撃時 / 守備時
check('攻撃時・守備時カードが出る', (await page.getByText('攻撃時 / 守備時フォーメーション').count()) > 0);
await page.getByRole('button', { name: '守備時' }).click();
await page.waitForTimeout(400);
check('守備時の一覧に切り替わる', (await page.getByText(/守備時の詳細/).count()) > 0);
await page.getByRole('button', { name: '攻撃時' }).click();
await page.waitForTimeout(400);
check('攻撃時に戻せる', (await page.getByText(/攻撃時の詳細/).count()) > 0);

await page.screenshot({ path: '/tmp/variants.png', fullPage: true });

/* ── 保存 → マイ戦術 → 共有 ───────────────────────────── */
await page.getByRole('button', { name: 'この戦術を保存' }).click();
await page.waitForTimeout(800);
check('保存するとマイ戦術が開く', (await page.getByRole('button', { name: 'マイ戦術', exact: true }).getAttribute('aria-current')) === 'page');
check('保存した戦術が一覧に出る', (await page.getByRole('list', { name: '保存した戦術' }).locator('li').count()) === 1);
const tacticTitle = await page.locator('article h2').innerText();
check('戦術の詳細が開いている', tacticTitle.startsWith('対4-2-3-1'), tacticTitle);

const anonBefore = await (await fetch(`${API}/tactics?select=share_id`, { headers: { apikey: 'mock' } })).json();
check('保存直後は非公開（未ログインからは見えない）', anonBefore.length === 0);
await page.getByRole('button', { name: '公開する' }).click();
await page.waitForTimeout(400);
const anonAfter = await (await fetch(`${API}/tactics?select=share_id&is_public=is.true`, { headers: { apikey: 'mock' } })).json();
check('公開すると共有リンクで見られる', anonAfter.length === 1);

await page.screenshot({ path: '/tmp/mytactics.png', fullPage: true });

// ログインしていない別のブラウザで共有リンクを開く
const guest = await browser.newPage({ viewport: { width: 420, height: 900 } });
guest.on('pageerror', (e) => errors.push(`guest: ${e}`));
await guest.goto(`${BASE}?t=${anonAfter[0].share_id}`, { waitUntil: 'networkidle' });
await guest.waitForTimeout(800);
check('共有リンクはログインなしで開ける', (await guest.locator('article h2').innerText()) === tacticTitle);
const guestHex = await guest.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--team-hex').trim());
check('共有画面は作った人のチームカラーで出る', guestHex === '#4d8dff', guestHex);
const hScroll = await guest.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
check('スマホ幅で横スクロールしない', hScroll <= 1, `${hScroll}px`);
await guest.screenshot({ path: '/tmp/shared-mobile.png', fullPage: true });
await guest.close();

// 共有カード画像が作れる（ダウンロードが発生する）
const [download] = await Promise.all([
  page.waitForEvent('download', { timeout: 8000 }).catch(() => null),
  page.getByRole('button', { name: '画像を保存' }).click(),
]);
check('共有カード画像を保存できる', !!download, download ? download.suggestedFilename() : 'なし');
if (download) await download.saveAs('/tmp/share-card.png');

/* ── 戦術ボード：保存した戦術を開いて動かす ─────────────── */
const shape = () => page.getByTestId('board-home-shape').innerText();
const scoreOf = async () => Number((await page.getByTestId('board-score').innerText()).replace('−', '-'));
const listTitle = await page.locator('article h2').innerText();
// 既定の名前は「対<相手> <攻撃時>/<守備時>」
const [savedAttack, savedDefense] = listTitle.split(' ')[1].split('/');
await page.getByRole('button', { name: '戦術ボードで編集' }).click();
await page.waitForTimeout(800);
check('マイ戦術から戦術ボードで開ける', (await page.getByTestId('board-score').count()) === 1);
check('開いた形が保存した攻撃時の形', (await shape()) === savedAttack, `${await shape()} / ${savedAttack}`);
check('内訳の表は最初は出ていない（シンプル表示）', (await page.getByText('起点別の内訳').count()) === 0);
check('ボールは最初は出ていない', (await page.locator('svg.touch-none circle[fill="#fef9c3"]').isVisible()) === false);

await page.getByRole('tab', { name: '守備のとき' }).click();
await page.waitForTimeout(500);
const defenseShape = await shape();
check('守備のときに切り替えると守備の形になる', defenseShape === savedDefense, `${defenseShape} / ${savedDefense}`);
await page.getByRole('tab', { name: '攻撃のとき' }).click();
await page.waitForTimeout(500);
check('攻撃のときに戻すと攻撃の形に戻る', (await shape()) === savedAttack);

// ドラッグで動かすと数字が変わり、1つ戻すで戻る
const before0 = await scoreOf();
const boardSvg = page.locator('svg.touch-none');
const bbox = await boardSvg.boundingBox();
const tokens = await page.evaluate(() => {
  const svg = document.querySelector('svg.touch-none');
  const hex = getComputedStyle(document.documentElement).getPropertyValue('--team-hex').trim();
  return [...svg.querySelectorAll('g')].filter((g) => !g.querySelector('g'))
    .map((g) => {
      const c = [...g.querySelectorAll('circle')].find((x) => x.getAttribute('fill') === hex);
      const t = g.querySelector('text');
      return c && t ? { n: t.textContent, x: +c.getAttribute('cx'), y: 68 - +c.getAttribute('cy') } : null;
    })
    .filter(Boolean);
});
check('自分の11人が描かれている', tokens.length === 11, `${tokens.length}人`);
const mover = tokens.filter((t) => t.x > 30).sort((a, b) => b.x - a.x)[3];
const scr = (x, y) => ({ x: bbox.x + (x / 105) * bbox.width, y: bbox.y + ((68 - y) / 68) * bbox.height });
const p0 = scr(mover.x, mover.y);
const p1 = scr(Math.min(100, mover.x + 12), mover.y);
await page.mouse.move(p0.x, p0.y);
await page.mouse.down();
await page.mouse.move(p1.x, p1.y, { steps: 10 });
await page.mouse.up();
await page.waitForTimeout(300);
const after0 = await scoreOf();
check('選手を動かすと期待値が変わる', after0 !== before0, `${before0} → ${after0}`);
check('1つ前との差が出る', (await page.getByTestId('board-delta').count()) === 1);
check('動かした選手の入れ替え欄が出る', (await page.getByTestId('board-selected').count()) === 1);
await page.getByRole('button', { name: '← 1つ戻す' }).click();
await page.waitForTimeout(300);
check('1つ戻すで元の期待値に戻る', (await scoreOf()) === before0, `${await scoreOf()}`);

// 控えと交代
await page.mouse.click(p0.x, p0.y);
await page.waitForTimeout(200);
const sel = page.locator('#board-slot-player');
const benchOpt = await sel.locator('optgroup[label^="控え"] option').first().getAttribute('value');
const benchName = (await sel.locator('optgroup[label^="控え"] option').first().innerText()).split('（')[0];
await sel.selectOption(benchOpt);
await page.waitForTimeout(300);
check('控えの選手と交代できる', (await page.getByTestId('board-selected').innerText()).includes(benchName), benchName);

// 自分の形を人数で選び直す
await page.getByTestId('board-home-picker').getByRole('button', { name: '4-4-2', exact: true }).click();
await page.waitForTimeout(400);
check('ボードでも自分の形をプリセットで替えられる', (await shape()) === '4-4-2');

// 詳しい表示
await page.getByRole('button', { name: 'くわしく見る' }).click();
await page.waitForTimeout(400);
check('くわしく見るで内訳が出る', (await page.getByText('起点別の内訳').count()) === 1);
await page.screenshot({ path: '/tmp/board-detail.png', fullPage: true });
await page.getByRole('button', { name: 'くわしい表示を閉じる' }).click();
await page.waitForTimeout(200);

// 上書き保存と、新しく保存
check('マイ戦術から開いた戦術は上書き保存できる', (await page.getByRole('button', { name: '上書き保存' }).count()) === 1);
await page.getByRole('button', { name: '上書き保存' }).click();
await page.waitForTimeout(500);
check('上書き保存の完了が出る', (await page.getByText('上書き保存しました').count()) === 1);
await page.screenshot({ path: '/tmp/board.png', fullPage: true });
await page.getByRole('button', { name: 'この戦術を保存' }).click();
await page.waitForTimeout(800);
check('ボードから新しく保存するとマイ戦術に増える', (await page.getByRole('list', { name: '保存した戦術' }).locator('li').count()) === 2);
const top = await page.locator('article h2').innerText();
check('ボードから保存した戦術の詳細が開く（名前は今の形から付く）', /^対\S+ 4-4-2\//.test(top), top);

/* ── ログインなしでボードを触る ──────────────────────── */
const guest2 = await browser.newPage({ viewport: { width: 390, height: 844 } });
guest2.on('pageerror', (e) => errors.push(`guest2: ${e}`));
await guest2.goto(BASE, { waitUntil: 'networkidle' });
await guest2.getByRole('button', { name: 'ログインせずにボードを触る' }).click();
await guest2.waitForTimeout(500);
check('ログインなしでもボードの期待値が出る', (await guest2.getByTestId('board-score').count()) === 1);
check('ログインなしの初期の形は 4-3-3 対 4-2-3-1',
  (await guest2.getByTestId('board-home-shape').innerText()) === '4-3-3' &&
  (await guest2.getByTestId('board-away-shape').innerText()) === '4-2-3-1');
check('ログインなしでは保存の代わりにログインの案内が出る', (await guest2.getByRole('button', { name: 'ログインして保存する' }).count()) === 1);
const hs2 = await guest2.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
check('ボードもスマホ幅で横スクロールしない', hs2 <= 1, `${hs2}px`);
await guest2.screenshot({ path: '/tmp/board-mobile.png', fullPage: true });
await guest2.close();

check('コンソールエラーなし', errors.length === 0, errors.slice(0, 3).join(' | '));

await browser.close();
console.log(failures === 0 ? '\n✅ E2E 全通過' : `\n❌ ${failures} 件失敗`);
process.exit(failures === 0 ? 0 : 1);
