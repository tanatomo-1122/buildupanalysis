import { DEFAULT_SKILLS } from '../data/skills';
import type { PositionId, SquadPlayer, UserProfile } from '../types';
import { sbInsert, sbRpc, sbSelect, sbUpdate, sbUpsert } from './supabase';

/** 登録する選手の人数 */
export const SQUAD_SIZE = 23;

interface ProfileRow {
  id: string;
  user_name: string;
  efootball_id: string | null;
  team_color: string | null;
  created_at: string;
}

interface SquadRow {
  id: string;
  profile_id: string;
  slot_index: number;
  name: string;
  position: string;
  sub_positions: string[] | null;
  attack_skill: string;
  defense_skill: string;
}

const toProfile = (r: ProfileRow): UserProfile => ({
  id: r.id,
  userName: r.user_name,
  efootballId: r.efootball_id ?? '',
  teamColor: r.team_color ?? 'blaze',
  createdAt: r.created_at,
});

const toSquadPlayer = (r: SquadRow): SquadPlayer => ({
  id: r.id,
  slotIndex: r.slot_index,
  name: r.name,
  position: r.position as PositionId,
  subPositions: (r.sub_positions ?? []) as PositionId[],
  attackSkill: r.attack_skill,
  defenseSkill: r.defense_skill,
});

/* ------------------------------------------------------------------ *
 * プロフィール
 * ------------------------------------------------------------------ */

/**
 * ログイン中の本人のプロフィール。RLS で自分の行しか返らないので条件は要らない。
 * 初回ログインなら Google の名前でクラブを作る。
 */
export const loadMyProfile = async (fallbackName: string): Promise<UserProfile> => {
  const rows = await sbSelect<ProfileRow>('profiles', 'select=*&limit=1');
  if (rows[0]) return toProfile(rows[0]);
  const created = await sbInsert<ProfileRow>('profiles', {
    user_name: fallbackName.trim() || 'MY CLUB',
  });
  return toProfile(created[0]);
};

export const updateMyProfile = async (
  id: string,
  patch: Partial<Pick<UserProfile, 'userName' | 'efootballId' | 'teamColor'>>,
): Promise<UserProfile> => {
  const body: Record<string, unknown> = {};
  if (patch.userName !== undefined) body.user_name = patch.userName;
  if (patch.efootballId !== undefined) body.efootball_id = patch.efootballId.trim() || null;
  if (patch.teamColor !== undefined) body.team_color = patch.teamColor;
  const rows = await sbUpdate<ProfileRow>('profiles', `id=eq.${encodeURIComponent(id)}`, body);
  return toProfile(rows[0]);
};

/** 以前（ログイン導入前）に eFootball ID で作ったデータを自分のものにする */
export const claimProfile = async (efootballId: string): Promise<UserProfile> => {
  const row = await sbRpc<ProfileRow>('claim_profile', { p_efootball_id: efootballId.trim() });
  return toProfile(row);
};

/* ------------------------------------------------------------------ *
 * 登録選手
 * ------------------------------------------------------------------ */

/** 未入力のスロットを埋めた 23 人ぶんの初期値 */
export const blankSquad = (): SquadPlayer[] => {
  const layout: PositionId[] = [
    'GK', 'GK', 'GK',
    'CB', 'CB', 'CB', 'CB',
    'RSB', 'RSB', 'LSB', 'LSB',
    'DMF', 'DMF', 'CMF', 'CMF',
    'RMF', 'LMF', 'OMF',
    'RWG', 'LWG',
    'ST', 'CF', 'CF',
  ];
  return layout.map((position, i) => ({
    id: `local-${i}`,
    slotIndex: i,
    name: '',
    position,
    subPositions: [],
    attackSkill: DEFAULT_SKILLS[position].attack,
    defenseSkill: DEFAULT_SKILLS[position].defense,
  }));
};

export const loadSquad = async (profileId: string): Promise<SquadPlayer[]> => {
  const rows = await sbSelect<SquadRow>(
    'squad_players',
    `select=*&profile_id=eq.${encodeURIComponent(profileId)}&order=slot_index.asc`,
  );
  if (rows.length === 0) return blankSquad();
  const saved = rows.map(toSquadPlayer);
  // 保存済みが 23 未満でも欠番を埋めて必ず 23 スロットにする
  const base = blankSquad();
  for (const p of saved) if (p.slotIndex >= 0 && p.slotIndex < base.length) base[p.slotIndex] = p;
  return base;
};

export const saveSquad = async (
  profileId: string,
  players: SquadPlayer[],
): Promise<SquadPlayer[]> => {
  const rows = players.map((p) => ({
    profile_id: profileId,
    slot_index: p.slotIndex,
    name: p.name,
    position: p.position,
    sub_positions: p.subPositions,
    attack_skill: p.attackSkill,
    defense_skill: p.defenseSkill,
    updated_at: new Date().toISOString(),
  }));
  const saved = await sbUpsert<SquadRow>('squad_players', rows, 'profile_id,slot_index');
  return saved.map(toSquadPlayer).sort((a, b) => a.slotIndex - b.slotIndex);
};

/** 名前が入っている選手だけを起用対象とする */
export const usablePlayers = (squad: SquadPlayer[]): SquadPlayer[] =>
  squad.filter((p) => p.name.trim().length > 0);
