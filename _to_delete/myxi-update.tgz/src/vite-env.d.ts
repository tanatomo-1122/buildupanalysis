/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL?: string;
  readonly VITE_SUPABASE_ANNON_KEY?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
